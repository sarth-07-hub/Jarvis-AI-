package com.jarvisai.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.MediaStore
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

private val BG = Color(0xFF050B0D)
private val PANEL = Color(0xFF0D191B)
private val NEON = Color(0xFF39F5B5)
private val CYAN = Color(0xFF38D9FF)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null

    private val micPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startListening()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        }

        setContent {
            var language by remember { mutableStateOf("ગુજરાતી") }
            var listening by remember { mutableStateOf(false) }
            var command by remember { mutableStateOf("") }
            var response by remember { mutableStateOf("નમસ્તે! હું JARVIS છું. મને શું કરવાનું છે?") }
            var busy by remember { mutableStateOf(false) }
            val history = remember { mutableStateListOf("JARVIS: System online. Welcome.") }
            val scope = rememberCoroutineScope()

            DisposableEffect(Unit) {
                recognizer?.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) { listening = true }
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() { listening = false }
                    override fun onError(error: Int) {
                        listening = false
                        response = "અવાજ ઓળખી શકાયો નથી. ફરી પ્રયાસ કરો અથવા લખો."
                    }
                    override fun onResults(results: Bundle?) {
                        listening = false
                        val spoken = results?.getStringArrayList(
                            SpeechRecognizer.RESULTS_RECOGNITION
                        )?.firstOrNull()
                        if (!spoken.isNullOrBlank()) {
                            command = spoken
                            history.add("YOU: $spoken")
                            scope.launch {
                                busy = true
                                response = runCommand(spoken)
                                history.add("JARVIS: $response")
                                speak(response, language)
                                busy = false
                            }
                        }
                    }
                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
                onDispose { }
            }

            MaterialTheme(colorScheme = darkColorScheme(
                background = BG, surface = PANEL, primary = NEON,
                onPrimary = BG, onBackground = Color.White, onSurface = Color.White
            )) {
                Column(
                    Modifier.fillMaxSize().background(BG).padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("J A R V I S", color = NEON, fontSize = 28.sp)
                    Text("FUTURISTIC HACKER • HYBRID AI", color = CYAN, fontSize = 11.sp)
                    Spacer(Modifier.height(20.dp))
                    Box(
                        Modifier.size(145.dp).background(PANEL, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(if (listening) "◉" else "◎", color = NEON, fontSize = 72.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(if (listening) "LISTENING..." else "SYSTEM READY", color = NEON)
                    Spacer(Modifier.height(14.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("LANGUAGE", color = CYAN, fontSize = 11.sp)
                        Spacer(Modifier.width(8.dp))
                        listOf("ગુજરાતી", "हिन्दी", "English").forEach { item ->
                            TextButton(onClick = { language = item }) {
                                Text(item, color = if (language == item) NEON else Color.LightGray)
                            }
                        }
                    }
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = PANEL),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Text("JARVIS RESPONSE", color = CYAN, fontSize = 11.sp)
                            Spacer(Modifier.height(6.dp))
                            Text(response, color = Color.White)
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    LazyColumn(
                        Modifier.weight(1f).fillMaxWidth()
                            .background(PANEL, RoundedCornerShape(12.dp)).padding(10.dp)
                    ) {
                        items(history.takeLast(25)) { line ->
                            Text(line, color = Color.LightGray, modifier = Modifier.padding(4.dp))
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = command, onValueChange = { command = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Type a command...") },
                        singleLine = true
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                if (ContextCompat.checkSelfPermission(
                                    this@MainActivity, Manifest.permission.RECORD_AUDIO
                                ) == PackageManager.PERMISSION_GRANTED) startListening()
                                else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = NEON)
                        ) { Text("🎙 Speak", color = BG) }
                        Button(
                            onClick = {
                                val text = command.trim()
                                if (text.isNotEmpty()) {
                                    history.add("YOU: $text")
                                    scope.launch {
                                        busy = true
                                        response = runCommand(text)
                                        history.add("JARVIS: $response")
                                        speak(response, language)
                                        busy = false
                                        command = ""
                                    }
                                }
                            },
                            modifier = Modifier.weight(1f), enabled = !busy,
                            colors = ButtonDefaults.buttonColors(containerColor = CYAN)
                        ) { Text(if (busy) "Thinking..." else "Run", color = BG) }
                    }
                    Text(
                        "Offline commands available • Online AI needs a secure backend",
                        color = Color.Gray, fontSize = 9.sp,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            }
        }
    }

    private fun startListening() {
        val r = recognizer ?: return
        val locale = when (Locale.getDefault().language) {
            "hi" -> "hi-IN"
            "en" -> "en-IN"
            else -> "gu-IN"
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, locale)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        r.startListening(intent)
    }

    private suspend fun runCommand(text: String): String {
        val s = text.lowercase(Locale.ROOT)
        return when {
            listOf("youtube", "યુટ્યુબ", "यूट्यूब").any(s::contains) ->
                launchApp("com.google.android.youtube", "YouTube")
            listOf("whatsapp", "વોટ્સએપ", "व्हाट्सएप").any(s::contains) ->
                launchApp("com.whatsapp", "WhatsApp")
            listOf("camera", "કેમેરા", "कैमरा").any(s::contains) -> try {
                startActivity(Intent(MediaStore.ACTION_IMAGE_CAPTURE))
                "Camera ખોલી રહ્યો છું."
            } catch (_: Exception) { "Camera app મળી નથી." }
            listOf("hello", "હેલો", "નમસ્તે", "હાય", "hi").any(s::contains) ->
                "Hello! હું JARVIS છું. હું તમારી કેવી મદદ કરી શકું?"
            else -> askBackend(text)
        }
    }

    private fun launchApp(packageName: String, name: String): String = try {
        val intent = packageManager.getLaunchIntentForPackage(packageName)
        if (intent == null) "$name તમારા ફોનમાં install નથી."
        else {
            startActivity(intent)
            "$name ખોલી રહ્યો છું."
        }
    } catch (_: Exception) { "$name ખોલી શકાયું નથી." }

    private suspend fun askBackend(prompt: String): String = withContext(Dispatchers.IO) {
        if (BuildConfig.AI_BACKEND_URL.contains("YOUR-BACKEND")) {
            return@withContext "Online AI backend હજી જોડાયેલું નથી. હાલમાં YouTube, WhatsApp, Camera અને greeting જેવા offline commands અજમાવો."
        }
        try {
            val connection = (URL(BuildConfig.AI_BACKEND_URL).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 12000
                readTimeout = 20000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
            }
            val body = JSONObject().put("message", prompt).toString()
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
            val result = stream.bufferedReader().use { it.readText() }
            connection.disconnect()
            JSONObject(result).optString("reply", "AI તરફથી જવાબ મળ્યો નથી.")
        } catch (_: Exception) {
            "Online AI સાથે જોડાણ થઈ શક્યું નથી. Internet અથવા backend તપાસો."
        }
    }

    private fun speak(text: String, language: String) {
        val locale = when (language) {
            "ગુજરાતી" -> Locale("gu", "IN")
            "हिन्दी" -> Locale("hi", "IN")
            else -> Locale("en", "IN")
        }
        val result = tts?.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts?.setLanguage(Locale.US)
        }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.setLanguage(Locale("gu", "IN"))
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}
